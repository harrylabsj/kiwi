"""RFQ v0.1.0 deterministic arithmetic reference; NOT a production approval engine."""
from __future__ import annotations
import hashlib
import json
from typing import Any

MAX_MINOR = 1_000_000_000_000

def integer(v: Any, name: str, lo: int = 0, hi: int = MAX_MINOR) -> int:
    if isinstance(v, bool) or not isinstance(v, int) or not lo <= v <= hi:
        raise ValueError(f"{name}: integer in [{lo}, {hi}] required")
    return v

def half_up(n: int, d: int) -> int:
    if n < 0 or d <= 0:
        raise ValueError("non-negative numerator / positive denominator required")
    return (2 * n + d) // (2 * d)

def split_tax(amount: int, basis: str, rate: int) -> dict[str, int]:
    integer(amount, "amount")
    integer(rate, "tax_rate_bps", hi=10000)
    if basis == "EXCLUSIVE":
        net = amount
        tax = half_up(amount * rate, 10000)
        gross = net + tax
    elif basis == "INCLUSIVE":
        gross = amount
        tax = half_up(amount * rate, 10000 + rate)
        net = gross - tax
    else:
        raise ValueError("unsupported tax basis")
    for v in (net, tax, gross): integer(v, "calculated amount")
    return {"net_minor": net, "tax_minor": tax, "gross_minor": gross}

def calculate(data: dict[str, Any]) -> dict[str, Any]:
    if data.get("schema_version") != "0.1.0" or data.get("currency") != "CNY" or data.get("rounding") != "HALF_UP_LINE":
        raise ValueError("unsupported version, currency or rounding")
    lines = data.get("lines")
    if not isinstance(lines, list) or not 1 <= len(lines) <= 100:
        raise ValueError("1..100 lines required")
    out = []
    seen = set()
    for row in lines:
        if row["line_id"] in seen: raise ValueError("duplicate line_id")
        seen.add(row["line_id"])
        q = integer(row["quantity"], "quantity", 1, 100000)
        p = integer(row["unit_price_minor"], "unit_price_minor")
        discount = integer(row["discount_minor"], "discount_minor")
        amount = q * p - discount
        if amount < 0: raise ValueError("discount exceeds line base")
        out.append({"line_id": row["line_id"], **split_tax(amount, row["tax_basis"], row["tax_rate_bps"])})
    ship = data["shipping"]
    freight = split_tax(ship["amount_minor"], ship["tax_basis"], ship["tax_rate_bps"])
    totals = {k: sum(x[k] for x in out) + freight[k] for k in ("net_minor", "tax_minor", "gross_minor")}
    for v in totals.values(): integer(v, "quote total")
    return {"lines": out, "shipping": freight, "totals": totals}

def canonical_digest(value: Any) -> str:
    """Reference RFQ canonical-json-v1, NOT KNP JCS. ASCII object keys; no floats."""
    def check(x: Any) -> None:
        if isinstance(x, float): raise ValueError("floats excluded")
        if isinstance(x, dict):
            for k, v in x.items():
                if not isinstance(k, str) or not k.isascii(): raise ValueError("ASCII keys required")
                check(v)
        elif isinstance(x, list):
            for v in x: check(v)
        elif x is not None and not isinstance(x, (str, bool, int)):
            raise ValueError("unsupported JSON value")
    check(value)
    b = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")
    return "sha256:" + hashlib.sha256(b).hexdigest()

def quote_digest(quote: dict[str, Any]) -> str:
    return canonical_digest({k: v for k, v in quote.items() if k not in ("content_digest", "status")})


def customer_projection(quote: dict[str, Any]) -> dict[str, Any]:
    """Minimal synthetic customer projection for digest examples, not a full PDF DTO.

    Production must add versioned merchant/customer display labels and as-of metadata
    before freeze; private data and internal evidence IDs are deliberately excluded.
    """
    inp = quote["pricing_input"]
    keys = ("line_id", "sku", "unit", "quantity", "unit_price_minor", "discount_minor", "tax_basis", "tax_rate_bps")
    shipkeys = ("amount_minor", "tax_basis", "tax_rate_bps")
    return {
        "quote_id": quote["quote_id"], "revision": quote["revision"],
        "currency": inp["currency"],
        "lines": [{k: row[k] for k in keys} for row in inp["lines"]],
        "shipping": {k: inp["shipping"][k] for k in shipkeys},
        "totals": quote["totals"], "valid_until": quote["valid_until"],
        "delivery_terms": quote["delivery_terms"], "payment_terms": quote["payment_terms"],
        "nonbinding_execution_boundary": True,
    }
