#!/usr/bin/env python3
"""Offline material self-check (L0). Not a Kiwi, auth, host or merchant pilot test."""
from __future__ import annotations
import hashlib
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

try:
    from jsonschema import Draft202012Validator, FormatChecker
    from referencing import Registry, Resource
except ImportError as exc:
    raise SystemExit("Install 04_reference/requirements.txt first; no validation has run.") from exc
from pricing_reference import calculate, canonical_digest, quote_digest, customer_projection

ROOT = Path(__file__).resolve().parent.parent
REPORT = ROOT / "05_acceptance/self-check-report.json"
EXCLUDED = {"MANIFEST.sha256", "05_acceptance/self-check-report.json"}
NAMESPACE = "urn:kiwi:rfq-workbench:0.1.0:"


def load(rel: str) -> Any:
    with (ROOT / rel).open(encoding="utf-8") as f:
        return json.load(f)


def instant(s: str) -> datetime:
    return datetime.fromisoformat(s.replace("Z", "+00:00"))


def semantic_check(slug: str, d: dict[str, Any]) -> None:
    """Illustrative structural/cross-field checks only; does not verify real-world authority."""
    if slug == "source-record":
        loc = d["locator"]
        if loc["kind"] == "text_span" and loc["character_end"] <= loc["character_start"]:
            raise ValueError("invalid text source range")
        if loc["kind"] == "csv_cell" and loc["row_end"] < loc["row_start"]:
            raise ValueError("invalid CSV source range")
    elif slug == "pricing-input":
        calculate(d)
    elif slug == "quote-revision":
        expected = calculate(d["pricing_input"])["totals"]
        if d["totals"] != expected:
            raise ValueError("quote totals do not match exact arithmetic")
        if d["content_digest"] != quote_digest(d):
            raise ValueError("quote digest mismatch")
        if instant(d["valid_until"]) <= instant(d["created_at"]):
            raise ValueError("invalid quote time interval")
    elif slug == "release-request":
        if instant(d["expires_at"]) <= instant(d["created_at"]):
            raise ValueError("invalid release time interval")
    elif slug == "fact-snapshot":
        seen = set()
        forbidden = re.compile(r"(^|[._-])(floor|floor_price|cost|profit|secret|token|password|credential)([._-]|$)", re.I)
        for row in d["fields"]:
            if forbidden.search(row["field_path"]):
                raise ValueError("private field in fact view")
            if row["field_path"] in seen:
                raise ValueError("duplicate fact path")
            seen.add(row["field_path"])
            if instant(row["expires_at"]) <= instant(row["verified_at"]):
                raise ValueError("invalid field freshness interval")
        stable = [{k: v for k, v in row.items() if k not in ("verified_at", "expires_at")} for row in d["fields"]]
        if d["content_fingerprint"] != canonical_digest(stable):
            raise ValueError("fact fingerprint mismatch")
    elif slug == "rfq-case":
        ids = [r["line_id"] for r in d["lines"]]
        if len(ids) != len(set(ids)):
            raise ValueError("duplicate line id")
        for row in d["lines"]:
            if not set(row["evidence_source_ids"]).issubset(set(d["source_ids"])):
                raise ValueError("line evidence missing from case sources")
    elif slug == "handoff-record" and d["receipt"] is not None:
        r = d["receipt"]
        if r["handoff_id"] != d["handoff_id"] or r["packet_digest"] != d["packet_digest"]:
            raise ValueError("receipt belongs to different handoff or packet")
    elif slug == "delivery-record":
        if d["status"] == "REPORTED_SENT" and d["verification"] is not None:
            raise ValueError("manual report cannot contain verified receipt")


def manifest_check() -> int:
    path = ROOT / "MANIFEST.sha256"
    if not path.exists():
        raise ValueError("missing MANIFEST.sha256; cannot claim package integrity")
    expected = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        digest, rel = line.split("  ", 1)
        if rel in expected or not re.fullmatch(r"[0-9a-f]{64}", digest):
            raise ValueError("malformed/duplicate manifest record")
        p = (ROOT / rel).resolve()
        if not p.is_relative_to(ROOT.resolve()) or not p.is_file():
            raise ValueError(f"invalid manifest path: {rel}")
        actual = hashlib.sha256(p.read_bytes()).hexdigest()
        if actual != digest:
            raise ValueError(f"manifest mismatch: {rel}")
        expected[rel] = digest
    actual_names = {
        str(p.relative_to(ROOT)) for p in ROOT.rglob("*")
        if p.is_file() and "__pycache__" not in p.parts and p.suffix != ".pyc"
        and str(p.relative_to(ROOT)) not in EXCLUDED
    }
    if actual_names != set(expected):
        raise ValueError(f"manifest coverage differs: missing={actual_names-set(expected)}, extra={set(expected)-actual_names}")
    return len(expected)


def run() -> dict[str, Any]:
    checks: list[dict[str, Any]] = []
    failures: list[dict[str, str]] = []
    def check(name: str, fn: Any) -> None:
        try:
            detail = fn()
            checks.append({"check": name, "status": "PASS", "detail": detail})
        except Exception as exc:  # Every failure is surfaced, never converted to a pass.
            failures.append({"check": name, "error_type": type(exc).__name__, "message": str(exc)})
            checks.append({"check": name, "status": "FAIL"})

    files = sorted((ROOT / "02_contracts").glob("*.schema.json"))
    schemas = {p.name.removesuffix(".schema.json"): json.loads(p.read_text(encoding="utf-8")) for p in files}
    if len(schemas) != 8:
        raise ValueError(f"expected 8 schemas, got {len(schemas)}")
    registry = Registry().with_resources((s["$id"], Resource.from_contents(s)) for s in schemas.values())
    validators = {k: Draft202012Validator(v, registry=registry, format_checker=FormatChecker()) for k, v in schemas.items()}
    def validate(slug: str, value: dict[str, Any]) -> None:
        validators[slug].validate(value)
        semantic_check(slug, value)

    for slug, schema in schemas.items():
        check("schema:" + slug, lambda schema=schema: Draft202012Validator.check_schema(schema))
    examples = {k: load(f"03_examples/{k}.json") for k in schemas}
    for slug, data in examples.items():
        check("example:" + slug, lambda slug=slug, data=data: validate(slug, data))

    vectors = load("04_reference/pricing-vectors.json")
    if len(vectors) != 10 or len({x['id'] for x in vectors}) != 10:
        raise ValueError("10 uniquely identified golden vectors required")
    for vector in vectors:
        def golden(v: dict[str, Any] = vector) -> dict[str, int]:
            validate("pricing-input", v["input"])
            out = calculate(v["input"])["totals"]
            if out != v["expected_totals"]:
                raise ValueError(f"expected {v['expected_totals']}, got {out}")
            return out
        check("golden:" + vector["id"], golden)

    negatives = load("04_reference/negative-vectors.json")
    if len(negatives) != 16 or len({x['id'] for x in negatives}) != 16:
        raise ValueError("16 uniquely identified negative vectors required")
    for vector in negatives:
        def negative(v: dict[str, Any] = vector) -> str:
            errors = list(validators[v["schema"]].iter_errors(v["data"]))
            if v["expected_failure"] == "schema":
                if not errors:
                    raise ValueError("expected schema rejection, but input was accepted")
                return "rejected_by_schema"
            if errors:
                raise ValueError("expected semantic rejection, but schema rejected first")
            try:
                semantic_check(v["schema"], v["data"])
            except ValueError:
                return "rejected_by_semantic_check"
            raise ValueError("expected semantic rejection, but input was accepted")
        check("negative:" + vector["id"], negative)

    def cross_refs() -> str:
        source, case, facts, quote, release = (examples[k] for k in ('source-record','rfq-case','fact-snapshot','quote-revision','release-request'))
        merchant = case['merchant_id']
        if any(x['merchant_id'] != merchant for x in (source, facts, quote, release)):
            raise ValueError('cross-merchant reference')
        if any(x['case_id'] != case['case_id'] for x in (source, facts, quote)):
            raise ValueError('case reference mismatch')
        if source['source_id'] not in case['source_ids'] or facts['case_revision'] != case['revision'] or quote['case_revision'] != case['revision']:
            raise ValueError('source/case version mismatch')
        if quote['snapshot_id'] != facts['snapshot_id'] or quote['fact_fingerprint'] != facts['content_fingerprint']:
            raise ValueError('quote fact mismatch')
        if quote['pricing_input'] != examples['pricing-input']:
            raise ValueError('pricing example differs from embedded quote')
        for key, qkey in [('quote_id','quote_id'),('quote_revision','revision'),('quote_content_digest','content_digest'),('recipient_ref','recipient_ref'),('policy_version','policy_version'),('fact_fingerprint','fact_fingerprint')]:
            if release[key] != quote[qkey]:
                raise ValueError('release binding mismatch: '+key)
        if release['public_projection_digest'] != canonical_digest(customer_projection(quote)):
            raise ValueError('public projection binding mismatch')
        if instant(release['expires_at']) > instant(quote['valid_until']):
            raise ValueError('release outlives quote')
        raw = (ROOT/'03_examples/synthetic-inquiry.txt').read_bytes()
        if source['content_sha256'] != 'sha256:'+hashlib.sha256(raw).hexdigest():
            raise ValueError('fixture source digest mismatch')
        return 'Synthetic intake-to-pending-release references consistent; delivery/handoff intentionally independent fixtures.'
    check('cross-references', cross_refs)

    def acceptance() -> dict[str, Any]:
        cases = load('05_acceptance/acceptance-matrix.json')['cases']
        if len(cases) != 80 or len({x['id'] for x in cases}) != 80:
            raise ValueError('80 unique acceptance ids required')
        if any(x['status'] != 'NOT_RUN' or x['evidence'] != [] for x in cases):
            raise ValueError('This baseline must not claim integration/host tests have run')
        if any(not all(x.get(k) for k in ('given','when','then','phase')) for x in cases):
            raise ValueError('Incomplete acceptance specification')
        return {'specifications':80,'executed':0,'status':'NOT_RUN'}
    check('acceptance-specification-structure', acceptance)

    def host() -> dict[str, int]:
        tools = load('06_host/tools.json')['tools']
        if len(tools) != 13 or len({x['name'] for x in tools}) != 13:
            raise ValueError('13 unique tool proposals required')
        for t in tools:
            Draft202012Validator.check_schema(t['inputSchema'])
            forbidden = {'merchant_id','principal_id','approved','confirmation_token'}
            if forbidden.intersection(t['inputSchema']['properties']) or t['name'].endswith('_approve'):
                raise ValueError('trusted identity or approval exposed as model input')
        skills = list((ROOT/'06_host/skills').glob('*/SKILL.md'))
        expected_skills = {'rfq-intake', 'quote-build-review', 'quote-release-followup'}
        if {p.parent.name for p in skills} != expected_skills:
            raise ValueError('three documented skill drafts required')
        return {'tool_proposals':13,'skill_drafts':3,'registered_or_installed':0}
    check('host-design-structure', host)
    check('manifest-integrity', manifest_check)
    return {
        'schema_version':'0.1.0', 'run_at':datetime.now(timezone.utc).isoformat(),
        'evidence_level':'L0', 'status':'PASS' if not failures else 'FAIL',
        'scope':'Offline design-package and reference-arithmetic self-check only.',
        'counts':{'schemas':8,'examples':8,'golden_pricing_vectors':10,'negative_vectors':16,'acceptance_specs_not_run':80,'tool_proposals':13,'skill_drafts':3},
        'production_status':{'L1_kiwi_integration':'NOT_RUN','L2_workbuddy_device':'NOT_RUN','L3_merchant_pilot':'NOT_RUN'},
        'checks':checks,'failures':failures,
        'limitations':['No production API, DB transaction, signature or approval verifier executed.','No real merchant evidence or customer PDF generated.','JSON Schema and local semantic checks do not establish identity or real-world source authority.']
    }

if __name__ == '__main__':
    try:
        result = run()
    except Exception as exc:
        result = {'evidence_level':'L0','status':'FAIL','failures':[{'error_type':type(exc).__name__,'message':str(exc)}]}
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':result['status'],'evidence_level':'L0','counts':result.get('counts'),'failures':result['failures'],'report':str(REPORT.relative_to(ROOT))},ensure_ascii=False,indent=2))
    sys.exit(0 if result['status']=='PASS' else 1)
