# 样例边界
全部为 SYNTHETIC 测试材料，不包含真实商家、客户或业务证据。
source→case→snapshot→quote→release 是一条待批准示例；delivery 与 handoff 引用单独的假设已批准对象，不表示前面的待批准报价已经发出。
artifact_sha256 仅用于展示字段格式，未附真实客户 PDF，不可用于发布。固定时钟为 2026-09-19T01:00:00Z，测试新鲜度时必须注入时钟。
Schema 校验只证明结构，不能替代身份、授权、引用一致性、实际来源与回执验证。
