# Kiwi 询报价工作台 · 技术设计交接包 v0.1.1

设计基线：Kiwi 0.10.0，commit 866dbe69583e3330198696861380043ccc721116；核查日期2026-09-19。

## 先读什么

01_design/technical-design.md 是主文档；同目录Word为同源排版版本。随后读 implementation-backlog.md，从M0基线/事务接缝开始。02_contracts是候选记录契约，06_host是拟新增工具与技能草稿，不是可直接安装的WorkBuddy插件。

## 实际包含

22章主设计、15项开发任务、8份JSON Schema、8组样例记录、10个计价金标算例、16个反例、参考计价与自检Python、80项未运行验收规格、14工具输入设计、3个技能草稿、来源与文件哈希清单。

## 自检

```bash
python3 -m pip install -r 04_reference/requirements.txt
python3 04_reference/validate_handoff.py
```

自检在本机不需要联网、数据库、生产token或Kiwi运行时（安装Python依赖可能联网）。它只验证交接材料和参考算术，不能证明生产业务、权限、WorkBuddy连接或真实用户需求已通过。80项集成/实机规格初始均为NOT_RUN，脚本不会将其改为通过。

## 边界

本包不包含Kiwi全仓库、生产服务实现、真实报价、PDF客户产物、审批凭证、正式平台ID或已审核连接器。所有示例均为合成数据。quote和release示例是待批准状态；delivery/handoff是独立的假设已批准对象，不构成真实执行证据。

公共目录网关继续“不碰实例”；商家私有报价状态、硬策略与批准在独立Merchant Core。首版不创建订单、不支付、不锁库存。正式导出只在可信人工批准后开放，导出、发送自述、送达验证、目标受理不得混淆。

## 文件完整性

MANIFEST.sha256覆盖交付文件，排除自身与会变化的05_acceptance/self-check-report.json。自检会重新检查清单，修改文件后应审阅变更并重新生成清单，不能绕过失败。报告明确L0与L1/L2/L3的区别。
