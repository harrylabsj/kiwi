# freight-reconciliation 宿主插件包 v0.3.0

由 scripts/build_host_package.py 确定性构建；勿手改。需要 Python 3.11+。首次使用先在本机安装锁定依赖：

```bash
python3 -m venv ~/.cache/freight-reconciliation/venv
~/.cache/freight-reconciliation/venv/bin/pip install -r requirements.txt
```

连接器由 .mcp.json 启动。本地人工确认页需单独启动：

```bash
read -s -p '管理页口令: ' FREIGHT_ADMIN_TOKEN; echo
export FREIGHT_ADMIN_TOKEN
./scripts/admin-local.sh
```

随后访问 http://127.0.0.1:8765/。连接器与管理页须使用同一 FREIGHT_RECON_ROOT；默认 ~/.local/share/freight-reconciliation。仅在本人电脑运行，勿将案件库放在网络共享盘。
