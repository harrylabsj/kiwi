@echo off
rem thin wrapper: keep logic in mcp-stdio.ps1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0mcp-stdio.ps1" %*
