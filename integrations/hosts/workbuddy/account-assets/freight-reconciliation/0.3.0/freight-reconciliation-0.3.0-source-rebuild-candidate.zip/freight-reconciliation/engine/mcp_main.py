"""打包布局启动器：engine/ 即 sys.path 根（构建时生成，勿手改）。"""
import sys
from pathlib import Path
ENGINE = Path(__file__).resolve().parent
for p in (str(ENGINE),):
    if p not in sys.path:
        sys.path.insert(0, p)
from adapters.mcp_server import main

if __name__ == "__main__":
    main()
