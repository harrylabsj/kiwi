#!/bin/bash
set -e
if [ -z "${FREIGHT_ADMIN_TOKEN:-}" ]; then
  echo "Set FREIGHT_ADMIN_TOKEN before starting the admin page" >&2
  exit 1
fi
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PY="${FREIGHT_PYTHON:-$HOME/.cache/freight-reconciliation/venv/bin/python}"
export FREIGHT_RECON_ROOT="${FREIGHT_RECON_ROOT:-$HOME/.local/share/freight-reconciliation}"
export PYTHONPATH="$ROOT/engine"
exec "$PY" "$ROOT/engine/adapters/admin_server.py"
