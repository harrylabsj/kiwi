#!/bin/bash
# 可移植根解析：WorkBuddy 注入 ${CODEBUDDY_PLUGIN_ROOT}，Hermes 等便携宿主
# 注入 ${PLUGIN_ROOT}；都没有时按脚本位置回退。三种形态共用本脚本。
if [ -n "${CODEBUDDY_PLUGIN_ROOT:-}" ] && [ -d "${CODEBUDDY_PLUGIN_ROOT}/engine" ]; then
  ROOT="${CODEBUDDY_PLUGIN_ROOT}"
elif [ -n "${PLUGIN_ROOT:-}" ] && [ -d "${PLUGIN_ROOT}/engine" ]; then
  ROOT="${PLUGIN_ROOT}"
else
  SELF="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
  ROOT="$(dirname "$SELF")"
fi
PY="${FREIGHT_PYTHON:-}"
if [ -z "$PY" ]; then
  if [ -x "$HOME/.cache/freight-reconciliation/venv/bin/python" ]; then
    PY="$HOME/.cache/freight-reconciliation/venv/bin/python"
  else
    PY="python3"
  fi
fi
export FREIGHT_RECON_ROOT="${FREIGHT_RECON_ROOT:-$HOME/.local/share/freight-reconciliation}"
exec "$PY" "$ROOT/engine/mcp_main.py"
