# portable root resolution: CODEBUDDY_PLUGIN_ROOT -> PLUGIN_ROOT -> script dir
$root = $null
if ($env:CODEBUDDY_PLUGIN_ROOT -and (Test-Path (Join-Path $env:CODEBUDDY_PLUGIN_ROOT 'engine'))) {
  $root = $env:CODEBUDDY_PLUGIN_ROOT
} elseif ($env:PLUGIN_ROOT -and (Test-Path (Join-Path $env:PLUGIN_ROOT 'engine'))) {
  $root = $env:PLUGIN_ROOT
} else {
  $root = Split-Path -Parent $PSScriptRoot
}
$py = $env:FREIGHT_PYTHON
if (-not $py) {
  $venv = Join-Path $HOME '.cache/freight-reconciliation/venv/Scripts/python.exe'
  if (Test-Path $venv) { $py = $venv } else { $py = 'python' }
}
if (-not $env:FREIGHT_RECON_ROOT) {
  $env:FREIGHT_RECON_ROOT = Join-Path $HOME '.local/share/freight-reconciliation'
}
& $py (Join-Path $root 'engine/mcp_main.py')
